﻿namespace BIWebApp.Models
{
    public class ChartDataViewModel
    {
        public List<string> Labels { get; set; }
        public List<int> Values { get; set; }
    }
}
